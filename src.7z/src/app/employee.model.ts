export interface Employee {
    emailId : string;
    password : string;
    empId : number;
    empName: string;
    IsRM: number;
}